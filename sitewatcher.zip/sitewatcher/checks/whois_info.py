# /checks/whois_info.py
from __future__ import annotations

import asyncio
import re
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
import contextlib
import httpx
import sqlite3

from .base import BaseCheck, CheckOutcome, Status
from ..config import WhoisConfig
import os
from pathlib import Path

# Утилиты извлечения из RDAP
def _get_event_date(obj: Dict[str, Any], action: str) -> Optional[datetime]:
    for ev in obj.get("events", []) or []:
        if ev.get("eventAction") == action and "eventDate" in ev:
            try:
                # ISO 8601 -> aware
                return datetime.fromisoformat(ev["eventDate"].replace("Z", "+00:00"))
            except Exception:
                continue
    return None

def _get_entities(obj: Dict[str, Any], role: str) -> List[Dict[str, Any]]:
    return [e for e in (obj.get("entities") or []) if role in (e.get("roles") or [])]

def _vcard_get(entity: Dict[str, Any], key: str) -> Optional[str]:
    # vcardArray = ["vcard", [[key, params, type, value], ...]]
    v = entity.get("vcardArray")
    if not isinstance(v, list) or len(v) < 2 or not isinstance(v[1], list):
        return None
    for item in v[1]:
        if isinstance(item, list) and len(item) >= 4 and item[0] == key:
            val = item[3]
            if isinstance(val, list):  # org может быть массивом
                return " ".join([str(x) for x in val if x])
            return str(val)
    return None

def _extract_snapshot(rdap: Dict[str, Any]) -> Dict[str, Any]:
    # registrar
    registrar_name = None
    for ent in _get_entities(rdap, "registrar"):
        registrar_name = _vcard_get(ent, "fn") or _vcard_get(ent, "org")
        if registrar_name:
            break
    # registrant
    registrant = None
    for ent in _get_entities(rdap, "registrant"):
        registrant = _vcard_get(ent, "fn") or _vcard_get(ent, "org")
        if registrant:
            break

    # nameservers
    ns = []
    for n in (rdap.get("nameservers") or []):
        name = n.get("ldhName") or n.get("unicodeName")
        if name:
            ns.append(name.lower().rstrip("."))

    # status codes
    status = sorted([s.lower() for s in (rdap.get("status") or [])])

    # dates
    expires = _get_event_date(rdap, "expiration")
    created = _get_event_date(rdap, "registration")
    updated = _get_event_date(rdap, "last changed") or _get_event_date(rdap, "last update of rdap database")

    out = {
        "registrar": registrar_name or "",
        "registrant": registrant or "",
        "nameservers": sorted(set(ns)),
        "status": status,
        "expires_at": expires.isoformat() if expires else None,
        "created_at": created.isoformat() if created else None,
        "updated_at": updated.isoformat() if updated else None,
        "rdap_source": rdap.get("port43") or "rdap.org",
    }
    return out

def _hash_snapshot(data: Dict[str, Any]) -> str:
    blob = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()

@dataclass
class _WhoisRow:
    snapshot_json: str
    fetched_at: datetime


class WhoisInfoCheck(BaseCheck):
    name = "whois"

    def __init__(self, domain: str, client: httpx.AsyncClient, cfg: WhoisConfig) -> None:
        super().__init__(domain)
        self.client = client
        self.cfg = cfg

        # Путь к БД берём из env (как и storage), по умолчанию ./sitewatcher.db в корне
        from .. import storage  # reuse DATABASE_PATH
        self.db_path = os.getenv("DATABASE_PATH", str(storage.DEFAULT_DB))

    async def run(self) -> CheckOutcome:
        prev = self._db_get()
        now = datetime.now(timezone.utc)

        must_refresh = True
        if prev:
            age_hours = (now - prev.fetched_at).total_seconds() / 3600.0
            must_refresh = age_hours >= float(self.cfg.refresh_hours)

        try:
            if must_refresh or not prev:
                snap, fetched_at = await self._fetch_snapshot(self.domain)
                self._db_upsert(snap, fetched_at)
            else:
                snap = json.loads(prev.snapshot_json)
                fetched_at = prev.fetched_at
        except Exception as e:
            return CheckOutcome(self.name, Status.UNKNOWN, f"whois/rdap error: {e.__class__.__name__}", {})

        # 2) вычислить статус по истечению
        expires_at = snap.get("expires_at")
        expiry_status, expiry_msg, days_left = self._expiry_status(expires_at)

        # 3) сравнить с предыдущим снимком (только отслеживаемые поля)
        changes_msg = ""
        if prev:
            before = json.loads(prev.snapshot_json)
            diff = self._diff_snapshots(before, snap, self.cfg.track_fields)
            if diff:
                parts = []
                for k, (old, new) in diff.items():
                    if isinstance(old, list) or isinstance(new, list):
                        # для NS/статусов покажем добавленные/удалённые
                        added = sorted(set(new) - set(old))
                        removed = sorted(set(old) - set(new))
                        if added:
                            parts.append(f"{k}+:{','.join(added)}")
                        if removed:
                            parts.append(f"{k}-:{','.join(removed)}")
                    else:
                        parts.append(f"{k}:{old or '-'}→{new or '-'}")
                changes_msg = "; ".join(parts)

        # 4) итоговый статус
        if expiry_status == Status.CRIT:
            status = Status.CRIT
        elif changes_msg:
            status = Status.WARN
        else:
            status = expiry_status  # OK или WARN, если близко к истечению

        # 5) сообщение
        msg_parts = []
        if expiry_msg:
            msg_parts.append(expiry_msg)
        if changes_msg:
            msg_parts.append(f"changed: {changes_msg}")
        if not msg_parts:
            msg_parts.append("no changes")
        message = "; ".join(msg_parts)

        metrics = {
            "expires_at": expires_at,
            "days_left": days_left,
            "registrar": snap.get("registrar"),
            "registrant": snap.get("registrant"),
            "nameservers": snap.get("nameservers"),
            "status_list": snap.get("status"),
            "fetched_at": fetched_at.isoformat(),
        }

        return CheckOutcome(self.name, status, message, metrics)

    # ---------- helpers ----------

    async def _fetch_snapshot(self, domain: str) -> Tuple[Dict[str, Any], datetime]:
        tld = domain.split(".")[-1].lower()
        override = self.cfg.tld_overrides.get(tld)
        if override and override.get("method") == "whois":
            txt = await self._whois_query(override["host"], domain)
            snap = self._parse_tcinet_ru(txt, whois_host=override["host"])
            return snap, datetime.now(timezone.utc)

        # иначе — RDAP по умолчанию
        rdap = await self._fetch_rdap(domain)
        snap = _extract_snapshot(rdap)
        return snap, datetime.now(timezone.utc)
    
    async def _fetch_rdap(self, domain: str) -> Dict[str, Any]:
        url = self.cfg.rdap_endpoint.format(domain=domain)
        r = await self.client.get(url, timeout=30.0, follow_redirects=True)
        r.raise_for_status()
        return r.json()

    # ------------ WHOIS (порт 43) ------------
    async def _whois_query(self, host: str, query: str) -> str:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(host=host, port=43), timeout=15.0)
        try:
            writer.write((query + "\r\n").encode("utf-8", "ignore"))
            await writer.drain()
            chunks: List[bytes] = []
            while True:
                try:
                    data = await asyncio.wait_for(reader.read(4096), timeout=10.0)
                except asyncio.TimeoutError:
                    break
                if not data:
                    break
                chunks.append(data)
            return b"".join(chunks).decode("utf-8", "ignore")
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    def _parse_tcinet_ru(self, text: str, whois_host: str) -> Dict[str, Any]:
        """
        Парсер формата whois.tcinet.ru (RU/РФ/SU).
        Поля: registrar, org/person, nserver*, state, created, paid-till, free-date.
        """
        lines = [l.strip() for l in text.splitlines()]
        kv = []
        for ln in lines:
            if not ln or ln.startswith("%"):
                continue
            if ":" in ln:
                k, v = ln.split(":", 1)
                kv.append((k.strip().lower(), v.strip()))

        def first(key: str) -> Optional[str]:
            for k, v in kv:
                if k == key:
                    return v
            return None

        registrar = first("registrar")
        org = first("org")
        person = first("person")
        registrant = org or person or ""

        # nserver: ns.example.ru. 1.2.3.4
        ns: List[str] = []
        for k, v in kv:
            if k == "nserver":
                name = v.split()[0].rstrip(".").lower()
                ns.append(name)
        nameservers = sorted(set(ns))

        # state: REGISTERED, DELEGATED, VERIFIED
        state = first("state") or ""
        statuses = [s.strip().lower() for s in state.split(",") if s.strip()]

        def parse_dt(val: Optional[str]) -> Optional[str]:
            if not val:
                return None
            s = val.strip()
            # Популярные форматы у tcinet: '2026-07-06T21:00:00Z' или просто '2026-07-06'
            for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d"):
                try:
                    dt = datetime.strptime(s, fmt)
                    # если без времени — считаем 00:00:00 UTC
                    if fmt == "%Y-%m-%d":
                        dt = dt.replace(hour=0, minute=0, second=0, tzinfo=timezone.utc)
                    else:
                        dt = dt.replace(tzinfo=timezone.utc)
                    return dt.isoformat()
                except ValueError:
                    continue
            # как запасной вариант попробуем parse ISO с Z→+00:00
            try:
                return datetime.fromisoformat(s.replace("Z", "+00:00")).isoformat()
            except Exception:
                return None

        created = parse_dt(first("created"))
        paid_till = parse_dt(first("paid-till"))

        return {
            "registrar": registrar or "",
            "registrant": registrant,
            "nameservers": nameservers,
            "status": statuses,
            "expires_at": paid_till,
            "created_at": created,
            "updated_at": None,
            "rdap_source": whois_host,
        }

    def _expiry_status(self, expires_at_iso: Optional[str]) -> Tuple[Status, str, Optional[int]]:
        if not expires_at_iso:
            return Status.UNKNOWN, "no expiry in rdap", None
        try:
            exp = datetime.fromisoformat(expires_at_iso)
        except Exception:
            # некоторые RDAP возвращают без таймзоны: добавим UTC
            try:
                exp = datetime.fromisoformat(expires_at_iso + "+00:00")
            except Exception:
                return Status.UNKNOWN, "bad expiry format", None
        now = datetime.now(timezone.utc)
        days_left = int((exp - now).total_seconds() // 86400)

        if days_left < 0:
            return Status.CRIT, f"domain expired {-days_left}d ago ({exp.date()} UTC)", days_left
        if days_left <= int(self.cfg.expiry_crit_days):
            return Status.CRIT, f"expires in {days_left}d ({exp.date()} UTC)", days_left
        if days_left <= int(self.cfg.expiry_warn_days):
            return Status.WARN, f"expires in {days_left}d ({exp.date()} UTC)", days_left
        return Status.OK, f"expires in {days_left}d ({exp.date()} UTC)", days_left

    def _diff_snapshots(self, old: Dict[str, Any], new: Dict[str, Any], keys: List[str]) -> Dict[str, Tuple[Any, Any]]:
        diff: Dict[str, Tuple[Any, Any]] = {}
        for k in keys:
            ov = old.get(k)
            nv = new.get(k)
            if ov != nv:
                # нормализуем списки
                if isinstance(ov, list):
                    ov = sorted(ov)
                if isinstance(nv, list):
                    nv = sorted(nv)
                if ov != nv:
                    diff[k] = (ov, nv)
        return diff

    # ---------- SQLite ----------

    def _db_get(self) -> Optional[_WhoisRow]:
        conn = sqlite3.connect(self.db_path)
        try:
            row = conn.execute("SELECT snapshot_json, fetched_at FROM whois_state WHERE domain = ?", (self.domain.lower(),)).fetchone()
            if not row:
                return None
            snap_json = row[0]
            try:
                fetched_at = datetime.fromisoformat(row[1])
            except Exception:
                fetched_at = datetime.now(timezone.utc)
            return _WhoisRow(snapshot_json=snap_json, fetched_at=fetched_at)
        finally:
            conn.close()

    def _db_upsert(self, snapshot: Dict[str, Any], fetched_at: datetime) -> None:
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute(
                "INSERT INTO whois_state(domain, snapshot_json, fetched_at) VALUES(?,?,?) "
                "ON CONFLICT(domain) DO UPDATE SET snapshot_json=excluded.snapshot_json, fetched_at=excluded.fetched_at, updated_at=CURRENT_TIMESTAMP",
                (self.domain.lower(), json.dumps(snapshot, ensure_ascii=False), fetched_at.isoformat()),
            )
            conn.commit()
        finally:
            conn.close()
