# /checks/rkn_block.py
from __future__ import annotations

import asyncio
import gzip
import ipaddress
import json
import re
import socket
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path
from typing import Optional, Set, Tuple

import httpx

from .base import BaseCheck, CheckOutcome, Status
from ..config import RknConfig

_DOMAIN_RE = re.compile(r"\b([a-z0-9-]+\.)+[a-z]{2,}\b", re.IGNORECASE)
_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")


@dataclass
class _Cache:
    fetched_at: datetime
    domains: Set[str]
    ips: Set[str]


class RknBlockCheck(BaseCheck):
    name = "rkn_block"

    # общий кэш на процесс
    _cache: Optional[_Cache] = None
    _lock = asyncio.Lock()

    def __init__(self, domain: str, client: httpx.AsyncClient, rkn_cfg: RknConfig) -> None:
        super().__init__(domain)
        self.client = client
        self.cfg = rkn_cfg

    async def run(self) -> CheckOutcome:
        try:
            cache = await self._ensure_cache()
        except Exception as e:
            return CheckOutcome(self.name, Status.UNKNOWN, f"source error: {e.__class__.__name__}", {})

        # 1) домен / поддомены
        dom = self.domain.lower().rstrip(".")
        matched_domain = self._match_domain(dom, cache.domains, self.cfg.match_subdomains)
        if matched_domain:
            return CheckOutcome(
                check=self.name,
                status=Status.CRIT,
                message=f"listed (domain match: {matched_domain})",
                metrics={"type": "domain", "matched": matched_domain, "source": "z-i", "fetched_at": cache.fetched_at.isoformat()},
            )

        # 2) IP совпадение
        matched_ips: list[str] = []
        if self.cfg.check_ip:
            for ip in await self._resolve_ips(dom):
                if ip in cache.ips:
                    matched_ips.append(ip)

        if matched_ips:
            return CheckOutcome(
                check=self.name,
                status=Status.CRIT,
                message=f"listed (ip match: {', '.join(matched_ips)})",
                metrics={"type": "ip", "matched": matched_ips, "source": "z-i", "fetched_at": cache.fetched_at.isoformat()},
            )

        return CheckOutcome(
            check=self.name,
            status=Status.OK,
            message="not listed",
            metrics={"source": "z-i", "fetched_at": cache.fetched_at.isoformat()},
        )

    # ---------------- internal: cache ----------------

    async def _ensure_cache(self) -> _Cache:
        """Возвращает кэшированный распарсенный индекс (в памяти),
        если on-disk индекс свежее TTL; иначе переизвлекает/перепарсивает.
        """
        async with self._lock:
            # 0) если в памяти свежо — отдаём
            if self._cache and not self._expired(self._cache.fetched_at):
                return self._cache

            # пути к файлам
            data_dir = Path(__file__).resolve().parent.parent / "data"
            raw_path = Path(self.cfg.cache_path) if self.cfg.cache_path else (data_dir / "z_i_dump.csv.gz")
            idx_path = Path(self.cfg.parse_cache_path) if self.cfg.parse_cache_path else (data_dir / "z_i_index.json.gz")

            # 1) пробуем взять готовый индекс с диска
            if idx_path.exists():
                try:
                    with gzip.open(idx_path, "rb") as f:
                        payload = json.loads(f.read().decode("utf-8"))
                    fetched_at = datetime.fromisoformat(payload["fetched_at"])
                    if not self._expired(fetched_at):
                        domains = set(payload.get("domains", []))
                        ips = set(payload.get("ips", []))
                        self._cache = _Cache(fetched_at=fetched_at, domains=domains, ips=ips)
                        return self._cache
                except Exception:
                    pass  # упал разбор индекса — продолжим

            # 2) если индекса нет или протух — обновляем raw и строим индекс
            text = await self._obtain_dump_text(self.cfg.z_i_url, raw_path)
            domains, ips = self._parse_dump(text)
            fetched_at = datetime.now(timezone.utc)

            # 3) сохраним индекс на диск (gz+json)
            try:
                idx_path.parent.mkdir(parents=True, exist_ok=True)
                with gzip.open(idx_path, "wb") as f:
                    f.write(json.dumps({
                        "fetched_at": fetched_at.isoformat(),
                        "domains": sorted(domains),
                        "ips": sorted(ips),
                    }).encode("utf-8"))
            except Exception:
                pass

            self._cache = _Cache(fetched_at=fetched_at, domains=domains, ips=ips)
            return self._cache

    def _expired(self, fetched_at: datetime) -> bool:
        ttl = timedelta(hours=int(self.cfg.cache_ttl_hours or 12))
        return datetime.now(timezone.utc) - fetched_at >= ttl

    async def _obtain_dump_text(self, url: str, raw_path: Path) -> str:
        """Возвращает текст CSV: пробует локальный gzip-дамп, если свежий; иначе скачивает и обновляет.
        Имеет фолбэки на dump-00..19.csv и mirrors.txt.
        """
        # 1) локальный raw (если свежий)
        if raw_path.exists():
            age = datetime.now(timezone.utc) - datetime.fromtimestamp(raw_path.stat().st_mtime, tz=timezone.utc)
            if age < timedelta(hours=int(self.cfg.cache_ttl_hours or 12)):
                try:
                    with gzip.open(raw_path, "rb") as f:
                        data = f.read()
                    try:
                        return data.decode("utf-8")
                    except UnicodeDecodeError:
                        return data.decode("cp1251", errors="ignore")
                except Exception:
                    pass  # не вышло — перекачаем

        # 2) качаем новый дамп (с фолбэками)
        text = await self._download_dump(url)

        # 3) сохраним сырой дамп как gzip
        try:
            raw_path.parent.mkdir(parents=True, exist_ok=True)
            with gzip.open(raw_path, "wb") as f:
                f.write(text.encode("utf-8", errors="ignore"))
        except Exception:
            pass

        return text

    async def _download_dump(self, url: str) -> str:
        """Основная попытка: dump.csv.gz → распаковать.
        Фолбэки: dump-00..19.csv (склейка), затем mirrors.txt (gz/обычный).
        """
        base = "https://raw.githubusercontent.com/zapret-info/z-i/master/"

        # 1) .gz
        try:
            r = await self.client.get(url, timeout=30.0, follow_redirects=True)
            r.raise_for_status()
            content = r.content
            # gzip sig
            if len(content) >= 2 and content[0] == 0x1F and content[1] == 0x8B:
                with gzip.GzipFile(fileobj=BytesIO(content)) as gz:
                    data = gz.read()
                try:
                    return data.decode("utf-8")
                except UnicodeDecodeError:
                    return data.decode("cp1251", errors="ignore")
            # plain text (на случай если пришёл прямой CSV)
            try:
                return r.text
            except UnicodeDecodeError:
                return content.decode("cp1251", errors="ignore")
        except Exception:
            pass

        # 2) частичные dump-00..19.csv
        parts = []
        for i in range(20):
            try:
                u = f"{base}dump-{i:02d}.csv"
                rr = await self.client.get(u, timeout=30.0, follow_redirects=True)
                if rr.status_code == 200 and rr.content:
                    try:
                        parts.append(rr.text)
                    except UnicodeDecodeError:
                        parts.append(rr.content.decode("cp1251", errors="ignore"))
            except Exception:
                continue
        if parts:
            return "\n".join(parts)

        # 3) mirrors.txt
        try:
            mirrors_txt = await self.client.get(f"{base}mirrors.txt", timeout=15.0, follow_redirects=True)
            if mirrors_txt.status_code == 200:
                mirrors = [ln.strip() for ln in mirrors_txt.text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
                for m in mirrors:
                    for cand in (f"{m.rstrip('/')}/dump.csv.gz", f"{m.rstrip('/')}/dump.csv"):
                        try:
                            mr = await self.client.get(cand, timeout=30.0, follow_redirects=True)
                            if mr.status_code == 200:
                                data = mr.content
                                if len(data) >= 2 and data[0] == 0x1F and data[1] == 0x8B:
                                    with gzip.GzipFile(fileobj=BytesIO(data)) as gz:
                                        raw = gz.read()
                                    try:
                                        return raw.decode("utf-8")
                                    except UnicodeDecodeError:
                                        return raw.decode("cp1251", errors="ignore")
                                try:
                                    return mr.text
                                except UnicodeDecodeError:
                                    return data.decode("cp1251", errors="ignore")
                        except Exception:
                            continue
        except Exception:
            pass

        raise RuntimeError("z-i dump not available via primary or mirrors")

    # ---------------- parsing & matching ----------------

    def _parse_dump(self, text: str) -> Tuple[Set[str], Set[str]]:
        doms: Set[str] = set()
        ips: Set[str] = set()
        for line in text.splitlines():
            # домены
            for m in _DOMAIN_RE.finditer(line.lower()):
                d = m.group(0).rstrip(".")
                if self._looks_like_domain(d):
                    doms.add(d)
            # ip
            for m in _IP_RE.finditer(line):
                ip = m.group(0)
                if self._valid_ipv4(ip):
                    ips.add(ip)
        return doms, ips

    @staticmethod
    def _looks_like_domain(d: str) -> bool:
        try:
            # отбросим IP-маски, если встретились
            ipaddress.ip_address(d)
            return False
        except Exception:
            pass
        parts = d.split(".")
        return len(parts) >= 2 and all(parts) and len(parts[-1]) >= 2

    @staticmethod
    def _valid_ipv4(ip: str) -> bool:
        try:
            ipaddress.IPv4Address(ip)
            return True
        except Exception:
            return False

    @staticmethod
    def _match_domain(domain: str, blocked: Set[str], subdomains: bool) -> Optional[str]:
        if domain in blocked:
            return domain
        if subdomains:
            labels = domain.split(".")
            for i in range(1, len(labels)):
                cand = ".".join(labels[i:])
                if cand in blocked:
                    return cand
        return None

    async def _resolve_ips(self, domain: str) -> Set[str]:
        loop = asyncio.get_running_loop()
        try:
            infos = await loop.getaddrinfo(domain, 80, type=socket.SOCK_STREAM)
        except Exception:
            return set()
        out: Set[str] = set()
        for family, _, _, _, sockaddr in infos:
            if family == socket.AF_INET:
                out.add(sockaddr[0])
        return out
