# sitewatcher/checks/http_basic.py
from __future__ import annotations

import time
from typing import Optional
import httpx
from .base import BaseCheck, CheckOutcome, Status


class HttpBasicCheck(BaseCheck):
    name = "http_basic"

    def __init__(
        self,
        domain: str,
        client: httpx.AsyncClient,
        timeout_s: int = 5,
        latency_warn_ms: int = 1000,
        latency_crit_ms: int = 3000,
        proxy: Optional[str] = None,
    ) -> None:
        super().__init__(domain)
        self.client = client
        self.timeout_s = timeout_s
        self.latency_warn_ms = latency_warn_ms
        self.latency_crit_ms = latency_crit_ms
        self.proxy = proxy  # (если позже потребуется пер-доменный прокси)

    async def run(self) -> CheckOutcome:
        origin_url = f"https://{self.domain}/"

        # 1) Первый ответ домена — без редиректов
        start1 = time.perf_counter()
        try:
            r1 = await self.client.get(origin_url, follow_redirects=False, timeout=self.timeout_s)
        except httpx.RequestError as e:
            elapsed_ms = int((time.perf_counter() - start1) * 1000)
            return CheckOutcome(
                check=self.name,
                status=Status.CRIT,
                message=f"request error: {e.__class__.__name__}",
                metrics={"latency_ms_initial": elapsed_ms, "url": origin_url},
            )

        elapsed1_ms = int((time.perf_counter() - start1) * 1000)
        code1 = r1.status_code

        # 2) Если редирект — получим финальную точку и суммарную задержку
        final_url = str(r1.url)
        final_code = code1
        redirects = 0
        total_ms = elapsed1_ms

        if 300 <= code1 < 400 and "location" in r1.headers:
            # построим абсолютный URL и пройдём цепочку редиректов
            try:
                start2 = time.perf_counter()
                r2 = await self.client.get(final_url, follow_redirects=True, timeout=self.timeout_s)
                elapsed2_ms = int((time.perf_counter() - start2) * 1000)
                redirects = len(r2.history) + 1  # включая первый 3xx
                final_url = str(r2.url)
                final_code = r2.status_code
                total_ms = elapsed1_ms + elapsed2_ms
            except httpx.RequestError:
                # не удалось пройти редирект — оставим финальную как неизвестную
                pass

        # 3) Определяем статус по коду первого ответа + порогам задержки
        if code1 >= 400:
            status = Status.CRIT
        elif 300 <= code1 < 400:
            status = Status.WARN
        else:
            # 200
            if elapsed1_ms >= self.latency_crit_ms:
                status = Status.CRIT
            elif elapsed1_ms >= self.latency_warn_ms:
                status = Status.WARN
            else:
                status = Status.OK

        # 4) Сообщение и метрики: показываем и первый ответ, и финальную точку, если была
        if redirects:
            msg = f"HTTP {code1} -> {final_code} @ {final_url}, latency {total_ms} ms (first {elapsed1_ms} ms)"
        else:
            msg = f"HTTP {code1}, latency {elapsed1_ms} ms"

        return CheckOutcome(
            check=self.name,
            status=status,
            message=msg,
            metrics={
                "code_initial": code1,
                "latency_ms_initial": elapsed1_ms,
                "redirects": redirects,
                "final_url": final_url,
                "final_code": final_code,
                "latency_ms_total": total_ms,
                "origin_url": origin_url,
            },
        )
