# /checks/ip_blacklist.py
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import List, Optional, Tuple

import dns.asyncresolver
import dns.resolver
import dns.exception

from .base import BaseCheck, CheckOutcome, Status


@dataclass
class Hit:
    ip: str
    zone: str
    a: List[str]
    txt: List[str]


class IpBlacklistCheck(BaseCheck):
    """
    Проверяет, попадают ли IPv4-адреса домена в набор DNSBL-зон.
    Логика:
      1) резолвим A-записи домена (и IPv6 при желании — off по умолчанию);
      2) для каждого IP и каждой зоны спрашиваем A/TXT по reversed_ip.zone;
      3) если есть ответ A — считаем как попадание, TXT пишем как причину;
      4) статусы: CRIT (есть попадания), WARN (нет A у домена), OK (чисто), UNKNOWN (ошибка).
    """
    name = "ip_blacklist"

    def __init__(
        self,
        domain: str,
        zones: List[str],
        dns_servers: Optional[List[str]] = None,
        timeout_s: int = 3,
        concurrency: int = 8,
        check_ipv6: bool = False,
    ) -> None:
        super().__init__(domain)
        self.zones = [z.strip().strip(".") for z in zones if z.strip()]
        self.timeout_s = float(timeout_s)
        self.concurrency = int(concurrency)
        self.check_ipv6 = bool(check_ipv6)

        self.resolver = dns.asyncresolver.Resolver(configure=True)
        self.resolver.lifetime = self.timeout_s
        self.resolver.timeout = self.timeout_s
        if dns_servers:
            self.resolver.nameservers = dns_servers

    # ---------- public ----------

    async def run(self) -> CheckOutcome:
        try:
            ips_v4, ips_v6 = await self._resolve_ips()
        except Exception as e:
            return CheckOutcome(self.name, Status.UNKNOWN, f"dns error: {e.__class__.__name__}", {})

        # если нет A — это подозрительно для сайта, пометим WARN (но не CRIT)
        if not ips_v4 and not (self.check_ipv6 and ips_v6):
            return CheckOutcome(self.name, Status.WARN, "no A/AAAA records", {"ips_v4": [], "ips_v6": []})

        # для совместимости с большинством DNSBL — проверяем только IPv4
        ips = ips_v4

        sem = asyncio.Semaphore(self.concurrency)
        tasks = [self._probe_ip_zone(sem, ip, zone) for ip in ips for zone in self.zones]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        hits: List[Hit] = []
        for r in results:
            if isinstance(r, Hit):
                hits.append(r)

        if hits:
            # формируем компактное сообщение: "IP @ zone" перечнем
            parts = []
            for h in hits:
                label = f"{h.ip}@{h.zone}"
                if h.txt:
                    label += f" ({'; '.join(h.txt)[:120]})"
                parts.append(label)
            message = f"listed: {', '.join(parts)}"
            metrics = {
                "hits": [
                    {"ip": h.ip, "zone": h.zone, "a": h.a, "txt": h.txt}
                    for h in hits
                ],
                "ips_v4": ips_v4,
                "ips_v6": ips_v6,
            }
            return CheckOutcome(self.name, Status.CRIT, message, metrics)

        return CheckOutcome(self.name, Status.OK, "not listed", {"ips_v4": ips_v4, "ips_v6": ips_v6})

    # ---------- internals ----------

    async def _resolve_ips(self) -> Tuple[List[str], List[str]]:
        # используем системный резолвер через asyncio для доменного имени
        loop = asyncio.get_running_loop()
        ips_v4: List[str] = []
        ips_v6: List[str] = []

        try:
            infos4 = await loop.getaddrinfo(self.domain, 80, family=0, type=0, proto=0)
        except Exception:
            infos4 = []

        for fam, _, _, _, sockaddr in infos4:
            host = sockaddr[0]
            if ":" in host:
                ips_v6.append(host)
            else:
                ips_v4.append(host)

        # уникализуем и отсортируем
        ips_v4 = sorted(set(ip for ip in ips_v4 if ip.count(".") == 3))
        ips_v6 = sorted(set(ips_v6))
        return ips_v4, ips_v6

    async def _probe_ip_zone(self, sem: asyncio.Semaphore, ip: str, zone: str):
        # reverse IPv4: 1.2.3.4 -> 4.3.2.1.zone
        try:
            rev = ".".join(reversed(ip.split(".")))
        except Exception:
            return None
        qname = f"{rev}.{zone}."

        async with sem:
            try:
                # A-ответ — сам факт листинга
                ans_a = await self.resolver.resolve(qname, "A", lifetime=self.timeout_s)
                a_values = [rr.address for rr in ans_a]
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.Timeout, dns.exception.DNSException):
                return None
            # TXT — причина/категория (если есть)
            txt_values: List[str] = []
            try:
                ans_txt = await self.resolver.resolve(qname, "TXT", lifetime=self.timeout_s)
                for rr in ans_txt:
                    try:
                        # rr.strings в dnspython 2.x → rr.strings / rr.to_text()
                        s = rr.to_text().strip('"')
                        if s:
                            txt_values.append(s)
                    except Exception:
                        pass
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.Timeout, dns.exception.DNSException):
                pass

        return Hit(ip=ip, zone=zone, a=a_values, txt=txt_values)
