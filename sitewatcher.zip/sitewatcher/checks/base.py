# /checks/base.py
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict

class Status(str, Enum):
    OK = "OK"
    WARN = "WARN"
    CRIT = "CRIT"
    UNKNOWN = "UNKNOWN"

@dataclass
class CheckOutcome:
    check: str
    status: Status
    message: str
    metrics: Dict[str, Any]

class BaseCheck:
    name: str = "base"

    def __init__(self, domain: str, **kwargs: Any) -> None:
        self.domain = domain
        self.kwargs = kwargs

    async def run(self) -> CheckOutcome: # pragma: no cover — интерфейс
        raise NotImplementedError
