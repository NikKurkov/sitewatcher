from __future__ import annotations

import asyncio
import ssl
from datetime import datetime, timezone
from typing import Optional

from .base import BaseCheck, CheckOutcome, Status


class TlsCertCheck(BaseCheck):
    name = "tls_cert"

    def __init__(self, domain: str, warn_days: int = 14) -> None:
        super().__init__(domain)
        self.warn_days = warn_days

    async def run(self) -> CheckOutcome:
        try:
            ssl_ctx = ssl.create_default_context()
            reader, writer = await asyncio.open_connection(
                self.domain, 443, ssl=ssl_ctx, server_hostname=self.domain
            )
            sslobj: Optional[ssl.SSLObject] = writer.get_extra_info("ssl_object")
            cert = sslobj.getpeercert() if sslobj else None
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

            if not cert:
                return CheckOutcome(self.name, Status.UNKNOWN, "no certificate", {})

            not_after = cert.get("notAfter")  # e.g. 'Apr 10 12:00:00 2026 GMT'
            if not not_after:
                return CheckOutcome(self.name, Status.UNKNOWN, "no notAfter in certificate", {})

            expires_at = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(
                tzinfo=timezone.utc
            )
            now = datetime.now(timezone.utc)
            days_left = int((expires_at - now).total_seconds() // 86400)
            date_str = expires_at.strftime("%Y-%m-%d")  # компактно для сообщения

            if days_left < 0:
                status = Status.CRIT
                msg = f"expired {-days_left}d ago ({date_str} UTC)"
            elif days_left <= self.warn_days:
                status = Status.WARN
                msg = f"expires in {days_left}d ({date_str} UTC)"
            else:
                status = Status.OK
                msg = f"expires in {days_left}d ({date_str} UTC)"

            return CheckOutcome(
                check=self.name,
                status=status,
                message=msg,
                metrics={
                    "days_left": days_left,
                    "expires_at": expires_at.isoformat(),  # ISO для машинной обработки
                    "not_after_raw": not_after,             # сырой отпечаток из cert
                },
            )
        except Exception as e:
            return CheckOutcome(self.name, Status.CRIT, f"tls error: {e.__class__.__name__}", {})
