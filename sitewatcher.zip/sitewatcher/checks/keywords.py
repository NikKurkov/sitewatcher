# /checks/keywords.py
from __future__ import annotations

import httpx
from typing import List
from .base import BaseCheck, CheckOutcome, Status


class KeywordsCheck(BaseCheck):
    name = "keywords"


    def __init__(self, domain: str, client: httpx.AsyncClient, timeout_s: int, keywords: List[str]):
        super().__init__(domain)
        self.client = client
        self.timeout_s = timeout_s
        self.keywords = keywords or []

    async def run(self) -> CheckOutcome:
        if not self.keywords:
            return CheckOutcome(self.name, Status.UNKNOWN, "no keywords configured", {"found": []})
        url = f"https://{self.domain}/"
        try:
            r = await self.client.get(url, follow_redirects=True, timeout=self.timeout_s)
            text = r.text
            missing = [k for k in self.keywords if k not in text]
            if missing:
                return CheckOutcome(self.name, Status.WARN, f"missing: {', '.join(missing)}", {
                "missing": missing,
                "found_count": len(self.keywords) - len(missing),
                })
            return CheckOutcome(self.name, Status.OK, "all keywords present", {
                "found_count": len(self.keywords)
            })
        except httpx.RequestError as e:
            return CheckOutcome(self.name, Status.CRIT, f"request error: {e.__class__.__name__}", {})
