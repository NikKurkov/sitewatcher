# /checks/ping.py
from __future__ import annotations

import asyncio
from typing import Optional

from .base import BaseCheck, CheckOutcome, Status

try:
    from icmplib import async_ping as icmp_async_ping # type: ignore
    HAVE_ICMP = True
except Exception:
    HAVE_ICMP = False


class PingCheck(BaseCheck):
    name = "ping"

    def __init__(self, domain: str):
        super().__init__(domain)

    async def _tcp_ping(self, port: int = 443, timeout: float = 2.0) -> float:
        start = asyncio.get_event_loop().time()
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(self.domain, port), timeout=timeout
            )
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return (asyncio.get_event_loop().time() - start) * 1000.0
        except Exception:
                return -1.0

    async def run(self) -> CheckOutcome:
        if HAVE_ICMP:
            try:
                host = await icmp_async_ping(self.domain, count=2, interval=0.2, timeout=2)
                if host.is_alive:
                    return CheckOutcome(self.name, Status.OK, f"icmp avg {host.avg_rtt:.0f} ms", {
                        "avg_rtt_ms": round(host.avg_rtt, 2)
                    })
                return CheckOutcome(self.name, Status.CRIT, "icmp no reply", {})
            except Exception:
                pass # fallback на TCP

        rtt = await self._tcp_ping()
        if rtt >= 0:
            return CheckOutcome(self.name, Status.OK, f"tcp {rtt:.0f} ms", {"rtt_ms": round(rtt, 2)})
        return CheckOutcome(self.name, Status.CRIT, "tcp connect failed", {})
