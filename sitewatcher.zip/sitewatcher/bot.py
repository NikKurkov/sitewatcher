# sitewatcher/bot.py
from __future__ import annotations

import random
from datetime import datetime, timezone, timedelta
import os
import re
import functools
import sqlite3
from pathlib import Path
import asyncio
from telegram.error import NetworkError
from telegram.request import HTTPXRequest
from typing import List
import html
import logging

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(level=logging.INFO, format='%(levelname)s:%(name)s:%(message)s')
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logger = logging.getLogger('sitewatcher.bot')

logger = logging.getLogger(__name__)

from .config import AppConfig, get_bot_token_from_env
from .dispatcher import Dispatcher
from . import storage

HELP_TEXT = (
    "/add_domain <name.ru> — добавить домен\n"
    "/remove_domain <name.ru> — удалить домен\n"
    "/list_domain — список доменов\n"
    "/check_domain <name.ru> — проверить домен\n"
    "/check_all — проверить все домены\n"
    "/clear_cache — очистить кэш RKN/WHOIS\n"
)

def _status_weight(s: str) -> int:
    s = (s or "").upper()
    if s == "CRIT":
        return 2
    if s in ("WARN", "UNKNOWN"):
        return 1
    return 0  # OK/другое

def _status_emoji(s: str) -> str:
    s = (s or "").upper()
    return {"CRIT": "🔴", "WARN": "🟡", "OK": "🟢", "UNKNOWN": "⚪"}.get(s, "⚪")

def _overall_from_results(results) -> str:
    worst = 0
    for r in results:
        st = getattr(r.status, "value", str(r.status))
        worst = max(worst, _status_weight(st))
    return {2: "CRIT", 1: "WARN", 0: "OK"}[worst]

def _parse_allowed_user_ids() -> set[int] | None:
    raw = os.getenv("TELEGRAM_ALLOWED_USER_IDS") or os.getenv("ALLOWED_USER_IDS")
    if not raw:
        return None
    ids: set[int] = set()
    for token in re.split(r"[,\s;]+", raw.strip()):
        if not token:
            continue
        try:
            ids.add(int(token))
        except ValueError:
            pass
    return ids or None

def requires_auth(func):
    @functools.wraps(func)
    async def wrapper(update, context, *args, **kwargs):
        allowed: set[int] | None = context.application.bot_data.get("allowed_user_ids")
        if allowed is not None:
            uid = update.effective_user.id if update.effective_user else None
            if uid is None or uid not in allowed:
                # мягко отдадим отказ и не пойдём дальше
                if getattr(update, "message", None):
                    await update.message.reply_text("⛔️ Доступ запрещён.")
                elif getattr(update, "callback_query", None):
                    await update.callback_query.answer("Доступ запрещён", show_alert=True)
                return
        return await func(update, context, *args, **kwargs)
    return wrapper

async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Unhandled error", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        await update.effective_message.reply_text("Упс, что-то пошло не так. Попробуйте ещё раз.")

async def safe_reply_html(message, text: str, retries: int = 3) -> None:
    delay = 1.0
    for attempt in range(1, retries + 1):
        try:
            await message.reply_html(text)
            return
        except NetworkError as e:
            # последний раз — пробрасываем, чтобы увиделось через on_error
            if attempt == retries:
                raise
            logger.warning("Telegram send failed (attempt %d/%d): %s", attempt, retries, e)
            await asyncio.sleep(delay)
            delay *= 2

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP_TEXT)

async def cmd_add_domain(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await update.message.reply_text("Укажите домен: /add_domain example.com")
        return
    name = context.args[0].strip().lower()
    storage.add_domain(name)
    await update.message.reply_text(f"Добавил: {name}")

async def cmd_remove_domain(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await update.message.reply_text("Укажите домен: /remove_domain example.com")
        return
    name = context.args[0].strip().lower()
    ok = storage.remove_domain(name)
    await update.message.reply_text("Удалил" if ok else "Не нашёл")

async def cmd_list_domain(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    items: List[str] = storage.list_domains()
    await update.message.reply_text("Список пуст" if not items else "\n".join(items))

async def _format_results(domain: str, results) -> str:
    # сохраним историю как раньше
    for r in results:
        storage.save_history(domain, r.check, r.status, r.message, r.metrics)

    overall = _overall_from_results(results)
    head = f"{_status_emoji(overall)} <b>{html.escape(domain)}</b> — {overall}"

    lines = [head]
    for r in results:
        lines.append(
            "• <code>{check}</code> — <b>{status}</b> — {msg}".format(
                check=html.escape(str(r.check)),
                status=html.escape(getattr(r.status, "value", str(r.status))),
                msg=html.escape(str(r.message)),
            )
        )
    return "\n".join(lines)

def _due_checks_for_domain(cfg: AppConfig, domain: str) -> List[str]:
    # смотрим по последним результатам и расписанию cfg.schedules
    sched = cfg.schedules.model_dump()
    due: List[str] = []
    for check_name, sc in sched.items():
        interval_min = int(sc.get("interval_minutes") or 0)
        if interval_min <= 0:
            continue
        mins = storage.minutes_since_last(domain, check_name)
        if mins is None or mins >= interval_min:
            due.append(check_name)
    return due

async def _run_checks_for_all_domains(context, warmup: bool) -> None:
    cfg: AppConfig = context.application.bot_data["cfg"]
    domains = storage.list_domains()
    if not domains:
        return

    async with Dispatcher(cfg) as d:
        for name in domains:
            try:
                due = _due_checks_for_domain(cfg, name)
                if not due:
                    continue
                results = await d.run_for(name, only_checks=due, use_cache=False)  # в фоне кэш не нужен
                for r in results:
                    storage.save_history(name, r.check, r.status, r.message, r.metrics)
                await maybe_send_alert(None, context, name, results)
            except Exception as e:
                logger.exception("scheduler: %s failed: %s", name, e)

async def job_warmup(context: ContextTypes.DEFAULT_TYPE) -> None:
    # первый проход — просто зафиксировать базовое состояние (maybe_send_alert сам не пошлёт,
    # если для домена ещё нет prev_overall, он только создаст baseline)
    await _run_checks_for_all_domains(context, warmup=True)

async def job_periodic(context: ContextTypes.DEFAULT_TYPE) -> None:
    await _run_checks_for_all_domains(context, warmup=False)

async def maybe_send_alert(update, context, domain: str, results) -> None:
    cfg: AppConfig = context.application.bot_data["cfg"]
    if not getattr(cfg.alerts, "enabled", True):
        return

    now = datetime.now(timezone.utc)
    overall = _overall_from_results(results)

    # прошлое состояние
    row = storage.get_alert_state(domain)
    prev_overall = row["last_overall"] if row else None
    last_sent_at = None
    if row and row["last_sent_at"]:
        try:
            last_sent_at = datetime.fromisoformat(row["last_sent_at"])
        except Exception:
            last_sent_at = None

    # политика: отправлять только при изменении (или только при ухудшении)
    if prev_overall is None:
        # первый раз просто запомним, без алерта
        storage.upsert_alert_state(domain, overall, None)
        return

    if cfg.alerts.policy == "worsen_only":
        if _status_weight(overall) <= _status_weight(prev_overall):
            # не ухудшилось — не шлём
            storage.upsert_alert_state(domain, overall, row["last_sent_at"] if row else None)
            return
    else:
        if overall == prev_overall:
            # нет изменений
            return

    # debounce
    if last_sent_at is not None:
        if (now - last_sent_at) < timedelta(seconds=int(cfg.alerts.debounce_sec or 0)):
            # слишком часто — молчим, но состояние обновим
            storage.upsert_alert_state(domain, overall, row["last_sent_at"])
            return

    # формируем короткое сообщение по домену
    head = f"{_status_emoji(overall)} <b>{html.escape(domain)}</b> — {overall} (was {prev_overall})"
    lines = [head]
    for r in results:
        lines.append(
            "• <code>{check}</code> — <b>{status}</b> — {msg}".format(
                check=html.escape(str(r.check)),
                status=html.escape(getattr(r.status, "value", str(r.status))),
                msg=html.escape(str(r.message)),
            )
        )
    text = "\n".join(lines)

    # куда слать
    alert_chat_id = (
        cfg.alerts.chat_id
        or (int(os.getenv("TELEGRAM_ALERT_CHAT_ID")) if os.getenv("TELEGRAM_ALERT_CHAT_ID") else None)
        or (update.effective_chat.id if update and update.effective_chat else None)
    )
    if not alert_chat_id:
        # ни одного канала — ничего не делаем, но состояние обновим
        storage.upsert_alert_state(domain, overall, None)
        return

    # посылаем безопасно (с ретраями, если у тебя есть safe_reply_html — можешь переиспользовать)
    try:
        await context.bot.send_message(chat_id=alert_chat_id, text=text, parse_mode="HTML", disable_web_page_preview=True)
        storage.upsert_alert_state(domain, overall, now.isoformat())
    except Exception as e:
        logger.exception("alert send failed for %s: %s", domain, e)
        # состояние всё равно обновим (чтобы не спамить)
        storage.upsert_alert_state(domain, overall, last_sent_at.isoformat() if last_sent_at else None)

async def cmd_check_domain(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not context.args:
        await update.message.reply_text("Укажите домен: /check_domain example.com")
        return
    name = context.args[0].strip().lower()
    cfg: AppConfig = context.application.bot_data["cfg"]
    async with Dispatcher(cfg) as d:
        results = await d.run_for(name, use_cache=True)  # <- для тяжелых чеков вернём кэш, если он свежий
        text = await _format_results(name, results)
        await update.message.reply_html(text)
        await maybe_send_alert(update, context, name, results)  # алерт только на смену общего статуса
    text = await _format_results(name, results)
    await safe_reply_html(update.message, text)
    await maybe_send_alert(update, context, name, results)

async def cmd_check_all(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cfg: AppConfig = context.application.bot_data["cfg"]
    names = storage.list_domains()
    if not names:
        await update.message.reply_text("Нет доменов в базе")
        return

    # опционально: /check_all --force  (или -f) — игнорировать кэш
    force = False
    if context.args:
        arg0 = (context.args[0] or "").lower()
        if arg0 in ("--force", "-f", "force"):
            force = True

    parts = []
    async with Dispatcher(cfg) as d:
        for name in names:
            # ключевое изменение: use_cache=not force
            results = await d.run_for(name, use_cache=not force)
            parts.append(await _format_results(name, results))
            await maybe_send_alert(update, context, name, results)

    await safe_reply_html(update.message, "\n\n".join(parts))

async def cmd_clear_cache(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cfg: AppConfig = context.application.bot_data["cfg"]

    # 1) WHOIS cache (таблица whois_state в основной БД)
    try:
        whois_deleted = storage.clear_whois_cache()
    except Exception as e:
        whois_deleted = -1
        logger.exception("clear_whois_cache failed: %s", e)

    # 2) RKN SQLite index (файл) + старые файлы-артефакты
    base_dir = Path(__file__).resolve().parent          # .../sitewatcher
    data_dir = base_dir / "data"
    rkn_db_path = Path(cfg.rkn.index_db_path) if getattr(cfg.rkn, "index_db_path", None) else (data_dir / "z_i_index.db")

    rkn_removed = False
    rkn_fallback_clear = False
    rkn_error: str | None = None

    if rkn_db_path.exists():
        try:
            rkn_db_path.unlink()           # удаляем файл индекса
            rkn_removed = True
        except Exception as e:
            # fallback: файл занят — почистим таблицы
            rkn_error = f"unlink failed: {e}"
            try:
                conn = sqlite3.connect(rkn_db_path)
                with conn:
                    conn.execute("DELETE FROM domains")
                    conn.execute("DELETE FROM ips")
                    conn.execute("DELETE FROM meta")
                conn.close()
                rkn_fallback_clear = True
            except Exception as e2:
                rkn_error += f"; fallback failed: {e2}"

    # 3) Удалим возможные старые артефакты (если есть)
    removed_extra: list[str] = []
    for extra in (data_dir / "z_i_dump.csv.gz", data_dir / "z_i_index.json.gz"):
        try:
            if extra.exists():
                extra.unlink()
                removed_extra.append(extra.name)
        except Exception:
            pass

    # Ответ пользователю
    parts = []
    parts.append(f"WHOIS: {'cleared ' + str(whois_deleted) + ' rows' if whois_deleted >= 0 else 'error'}")
    if rkn_removed:
        parts.append(f"RKN: removed file {rkn_db_path.name}")
    elif rkn_fallback_clear:
        parts.append("RKN: file busy, tables cleared")
    else:
        parts.append("RKN: nothing to remove" if not rkn_error else f"RKN: error ({rkn_error})")
    if removed_extra:
        parts.append(f"extra: removed {', '.join(removed_extra)}")

    await update.message.reply_text("✅ The cache is cleared: " + "; ".join(parts))


def run_bot(cfg: AppConfig) -> None:
    token = get_bot_token_from_env()
    if not token:
        raise RuntimeError("TELEGRAM_TOKEN не задан в .env")

    request = HTTPXRequest(
        http_version="1.1",      # принудительно HTTP/1.1 для стабильности
        connect_timeout=10.0,
        read_timeout=30.0,
        write_timeout=30.0,
        # если нужен прокси: задаём TELEGRAM_PROXY в .env или окружении
        proxy=os.getenv("TELEGRAM_PROXY")  # например: http://user:pass@host:3128
    )

    app = Application.builder().token(token).request(request).build()
    app.bot_data["cfg"] = cfg

    allowed_ids = _parse_allowed_user_ids()
    if allowed_ids:
        logger.info("Access limited to %d user(s)", len(allowed_ids))
    else:
        logger.warning("Access is open to all users; set TELEGRAM_ALLOWED_USER_IDS to restrict.")
    app.bot_data["allowed_user_ids"] = allowed_ids

    app.add_handler(CommandHandler(["start", "help"], requires_auth(cmd_help)))
    app.add_handler(CommandHandler("add_domain", requires_auth(cmd_add_domain)))
    app.add_handler(CommandHandler("remove_domain", requires_auth(cmd_remove_domain)))
    app.add_handler(CommandHandler("list_domain", requires_auth(cmd_list_domain)))
    app.add_handler(CommandHandler("check_domain", requires_auth(cmd_check_domain)))
    app.add_handler(CommandHandler("check_all", requires_auth(cmd_check_all)))
    app.add_handler(CommandHandler("clear_cache", requires_auth(cmd_clear_cache)))
    app.add_error_handler(on_error)

    # Включаем хенлдлер планировщика
    jq = app.job_queue
    sch = cfg.scheduler

    if getattr(sch, "enabled", True):
        # единоразовый «тёплый» запуск после старта, чтобы заполнить baseline alert_state
        if getattr(sch, "run_on_startup", True):
            jq.run_once(job_warmup, when=5)  # через 5 секунд после старта

        # периодическая задача
        interval = max(60, int(sch.interval_minutes) * 60)          # минимум 60 сек
        jitter = max(0, int(getattr(sch, "jitter_seconds", 0)))
        first = random.randint(1, max(1, jitter)) if jitter > 0 else interval

        jq.run_repeating(
            job_periodic,
            interval=interval,
            first=first,
            name="sitewatcher:periodic_checks",
        )
        logger.info("Scheduler enabled: every %s min (first in ~%s s)", sch.interval_minutes, first)
    else:
        logger.info("Scheduler disabled by config")

    # Слушаем бота
    app.run_polling()