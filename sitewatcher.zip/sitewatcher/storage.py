# storage.py
from __future__ import annotations


import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
import os

DEFAULT_DB = Path(os.getenv("DATABASE_PATH", "./sitewatcher.db"))

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS domains (
    name TEXT PRIMARY KEY,
    settings_json TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT NOT NULL,
    ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    check_type TEXT NOT NULL,
    status TEXT NOT NULL,
    message TEXT NOT NULL,
    metrics_json TEXT NOT NULL,
    FOREIGN KEY(domain) REFERENCES domains(name)
);
CREATE INDEX IF NOT EXISTS idx_history_domain_id ON history(domain,id);
CREATE INDEX IF NOT EXISTS idx_history_domain_check ON history(domain,check_type);
CREATE TABLE IF NOT EXISTS whois_state (
  domain TEXT PRIMARY KEY,
  snapshot_json TEXT NOT NULL,
  fetched_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS dns_state (
  domain TEXT PRIMARY KEY,
  snapshot_json TEXT NOT NULL,   -- {"ips_v4":[...], "ips_v6":[...]}
  fetched_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS alert_state (
  domain TEXT PRIMARY KEY,
  last_overall TEXT NOT NULL,
  last_sent_at TIMESTAMP
);
"""


def _connect(db_path: Path = DEFAULT_DB) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: Path = DEFAULT_DB) -> None:
    conn = _connect(db_path)
    try:
        conn.executescript(SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


def add_domain(name: str, settings: Optional[Dict[str, Any]] = None) -> bool:
    init_db()
    conn = _connect()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO domains(name, settings_json) VALUES(?, ?)",
            (name.lower(), json.dumps(settings or {})),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def remove_domain(name: str) -> bool:
    init_db()
    conn = _connect()
    try:
        cur = conn.execute("DELETE FROM domains WHERE name = ?", (name.lower(),))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def list_domains() -> List[str]:
    init_db()
    conn = _connect()
    try:
        rows = conn.execute("SELECT name FROM domains ORDER BY name").fetchall()
        return [r["name"] for r in rows]
    finally:
        conn.close()


def save_history(domain: str, check: str, status: str, message: str, metrics: Dict[str, Any]) -> None:
    init_db()
    conn = _connect()
    try:
        conn.execute(
            "INSERT INTO history(domain, check_type, status, message, metrics_json) VALUES(?,?,?,?,?)",
            (domain.lower(), check, status, message, json.dumps(metrics)),
        )
        conn.commit()
    finally:
        conn.close()


def last_results(domain: str, limit: int = 10) -> List[sqlite3.Row]:
    init_db()
    conn = _connect()
    try:
        rows = conn.execute(
            "SELECT * FROM history WHERE domain = ? ORDER BY id DESC LIMIT ?",
            (domain.lower(), limit),
        ).fetchall()
        return rows
    finally:
        conn.close()


def clear_whois_cache(db_path: Path = DEFAULT_DB) -> int:
    """
    Очищает кэш WHOIS (таблица whois_state). Возвращает число удалённых записей.
    Если таблицы нет — вернёт 0.
    """
    init_db(db_path)
    conn = _connect(db_path)
    try:
        try:
            cur = conn.execute("SELECT COUNT(*) FROM whois_state")
            count = int(cur.fetchone()[0])
        except sqlite3.OperationalError:
            return 0
        conn.execute("DELETE FROM whois_state")
        conn.commit()
        return count
    finally:
        conn.close()

def get_alert_state(domain: str) -> Optional[sqlite3.Row]:
    init_db()
    conn = _connect()
    try:
        row = conn.execute(
            "SELECT last_overall, last_sent_at FROM alert_state WHERE domain = ?",
            (domain.lower(),),
        ).fetchone()
        return row
    finally:
        conn.close()

def upsert_alert_state(domain: str, last_overall: str, last_sent_at: Optional[str]) -> None:
    init_db()
    conn = _connect()
    try:
        conn.execute(
            """
            INSERT INTO alert_state(domain,last_overall,last_sent_at)
            VALUES(?,?,?)
            ON CONFLICT(domain) DO UPDATE SET
                last_overall=excluded.last_overall,
                last_sent_at=excluded.last_sent_at
            """,
            (domain.lower(), last_overall, last_sent_at),
        )
        conn.commit()
    finally:
        conn.close()

def last_history_for_check(domain: str, check_type: str) -> Optional[sqlite3.Row]:
    init_db()
    conn = _connect()
    try:
        row = conn.execute(
            "SELECT * FROM history WHERE domain = ? AND check_type = ? ORDER BY id DESC LIMIT 1",
            (domain.lower(), check_type),
        ).fetchone()
        return row
    finally:
        conn.close()

def minutes_since_last(domain: str, check_type: str) -> Optional[int]:
    row = last_history_for_check(domain, check_type)
    if not row:
        return None
    try:
        # ts — TIMESTAMP DEFAULT CURRENT_TIMESTAMP; sqlite3.Row → строка 'YYYY-MM-DD HH:MM:SS'
        from datetime import datetime, timezone
        ts = row["ts"]
        dt = datetime.fromisoformat(str(ts))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        return int((now - dt).total_seconds() // 60)
    except Exception:
        return None
