# config.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Literal
import os
import yaml
from pydantic import BaseModel, Field


class ChecksModel(BaseModel):
    http_basic: bool = True
    tls_cert: bool = True
    keywords: bool = False
    ping: bool = True
    rkn_block: bool = True
    ports: bool = False
    whois: bool = True
    ip_blacklist: bool = False
    ip_change: bool = True

class CheckSchedule(BaseModel):
    interval_minutes: int                # как часто запускать планировщиком
    cache_ttl_minutes: int = 0           # сколько минут можно отдавать кэш при ручном /check_* (0 = не кэшировать)

class SchedulesConfig(BaseModel):
    http_basic: CheckSchedule = Field(default_factory=lambda: CheckSchedule(5, 0))
    tls_cert:  CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 1440))
    ping:      CheckSchedule = Field(default_factory=lambda: CheckSchedule(5, 0))
    rkn_block: CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 1440))
    ports:     CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 1440))
    whois:     CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 1440))
    ip_blacklist: CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 1440))
    ip_change: CheckSchedule = Field(default_factory=lambda: CheckSchedule(1440, 0))

class SchedulerConfig(BaseModel):
    enabled: bool = True
    interval_minutes: int = 10      # период фоновых проверок
    jitter_seconds: int = 30        # случайная задержка на старте, чтобы не бахать все сразу
    run_on_startup: bool = True     # прогнать один тёплый запуск после старта (без спама)

class AlertsConfig(BaseModel):
    enabled: bool = True
    policy: Literal["overall_change", "worsen_only"] = "overall_change"
    debounce_sec: int = 120         # минимум секунд между алертами по одному домену
    cooldown_sec: int = 600         # не используется прямо сейчас, оставим на будущее
    chat_id: Optional[int] = None   # если задано, алерты всегда сюда

class IpChangeConfig(BaseModel):
    refresh_hours: int = 6          # как часто обновлять снапшот в БД
    include_ipv6: bool = True       # учитывать ли AAAA при сравнении

class IpBLConfig(BaseModel):
    zones: List[str] = Field(
        default_factory=lambda: [
            "zen.spamhaus.org",       # Spamhaus (разумный лимит на бесплатный резолв)
            "dnsbl.dronebl.org",      # DroneBL
            "rbl.efnetrbl.org",       # EFnet
            # при необходимости добавляй иные, некоторые требуют регистрацию (Barracuda и др.)
        ]
    )
    dns_servers: Optional[List[str]] = None   # например: ["1.1.1.1", "8.8.8.8"]
    timeout_s: int = 3
    concurrency: int = 8
    check_ipv6: bool = False                  # большинство DNSBL — только для IPv4

class WhoisConfig(BaseModel):
    rdap_endpoint: str = "https://rdap.org/domain/{domain}"
    refresh_hours: int = 12
    expiry_warn_days: int = 30
    expiry_crit_days: int = 0
    track_fields: List[str] = Field(default_factory=lambda: ["registrar", "registrant", "nameservers", "status"])
    tld_overrides: Dict[str, Dict[str, str]] = Field(
        default_factory=lambda: {
            "ru": {"method": "whois", "host": "whois.tcinet.ru"},
            "xn--p1ai": {"method": "whois", "host": "whois.tcinet.ru"},  # .рф
            "su": {"method": "whois", "host": "whois.tcinet.ru"},
        }
    )

class PortSpec(BaseModel):
    port: int
    host: Optional[str] = None
    tls: bool = False
    send: Optional[str] = None
    expect: Optional[str] = None
    timeout_s: Optional[int] = None

class PortsConfig(BaseModel):
    connect_timeout_s: int = 3
    read_timeout_s: int = 2
    read_bytes: int = 128
    targets: List[PortSpec] = Field(
        default_factory=lambda: [
            PortSpec(port=80),
            PortSpec(port=443, tls=True),
            PortSpec(port=22),
            PortSpec(port=25),
        ]
    )

class RknConfig(BaseModel):
    source: Literal["z-i"] = "z-i"
    z_i_url: str = "https://raw.githubusercontent.com/zapret-info/z-i/master/dump.csv.gz"
    cache_ttl_hours: int = 12
    index_db_path: str | None = None
    match_subdomains: bool = True
    check_ip: bool = True

class DefaultsModel(BaseModel):
    http_timeout_s: int = 5
    latency_warn_ms: int = 1000
    latency_crit_ms: int = 3000
    tls_warn_days: int = 14
    proxy: Optional[str] = None
    keywords: List[str] = Field(default_factory=list)
    checks: ChecksModel = Field(default_factory=ChecksModel)

class DomainModel(BaseModel):
    name: str
    checks: Optional[ChecksModel] = None
    keywords: Optional[List[str]] = None
    latency_warn_ms: Optional[int] = None
    latency_crit_ms: Optional[int] = None
    tls_warn_days: Optional[int] = None
    proxy: Optional[str] = None
    ports: Optional[List[PortSpec]] = None

class SchedulerModel(BaseModel):
    enabled: bool = True
    interval_minutes: int = 10
    jitter_seconds: int = 30
    run_on_startup: bool = True

class AppConfig(BaseModel):
    version: int = 1
    defaults: DefaultsModel = Field(default_factory=DefaultsModel)
    scheduler: SchedulerConfig = Field(default_factory=SchedulerConfig)
    scheduler: SchedulerModel = Field(default_factory=SchedulerModel)
    domains: List[DomainModel] = Field(default_factory=list)
    rkn: RknConfig = Field(default_factory=RknConfig)
    ports: PortsConfig = Field(default_factory=PortsConfig)
    whois: WhoisConfig = Field(default_factory=WhoisConfig)
    ipbl: IpBLConfig = Field(default_factory=IpBLConfig)
    ipchange: IpChangeConfig = Field(default_factory=IpChangeConfig)
    alerts: AlertsConfig = Field(default_factory=AlertsConfig)
    schedules: SchedulesConfig = Field(default_factory=SchedulesConfig)

# ----- Загрузка -----
CONFIG_PATH = Path(__file__).with_suffix("").parent / "data" / "config.yaml"


def load_config(path: Optional[Path] = None) -> AppConfig:
    cfg_path = Path(path) if path else CONFIG_PATH
    with open(cfg_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    return AppConfig.model_validate(data)

# ----- Слияние настроек (дефолты + домен) -----

@dataclass
class ResolvedSettings:
    name: str
    http_timeout_s: int
    latency_warn_ms: int
    latency_crit_ms: int
    tls_warn_days: int
    proxy: Optional[str]
    keywords: List[str]
    checks: ChecksModel


def resolve_settings(cfg: AppConfig, domain: str) -> ResolvedSettings:
    d = next((d for d in cfg.domains if d.name.lower() == domain.lower()), None)
    defaults = cfg.defaults
    return ResolvedSettings(
        name=domain,
        http_timeout_s=defaults.http_timeout_s,
        latency_warn_ms=d.latency_warn_ms if d and d.latency_warn_ms is not None else defaults.latency_warn_ms,
        latency_crit_ms=d.latency_crit_ms if d and d.latency_crit_ms is not None else defaults.latency_crit_ms,
        tls_warn_days=d.tls_warn_days if d and d.tls_warn_days is not None else defaults.tls_warn_days,
        proxy=(d.proxy if d and d.proxy is not None else defaults.proxy),
        keywords=(d.keywords if d and d.keywords is not None else defaults.keywords),
        checks=(d.checks if d and d.checks is not None else defaults.checks),
    )


def get_bot_token_from_env() -> Optional[str]:
    return os.getenv("TELEGRAM_TOKEN")
