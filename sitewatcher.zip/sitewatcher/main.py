# sitewatcher/main.py
from __future__ import annotations


from dotenv import load_dotenv
load_dotenv()
import argparse
import asyncio
from typing import List

from dotenv import load_dotenv
load_dotenv()

from .config import load_config
from .dispatcher import Dispatcher
from .bot import run_bot
from . import storage

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="sitewatcher")
    p.add_argument("mode", choices=["bot", "check_all", "check_domain"], help="run mode")
    p.add_argument("name", nargs="?", help="domain for check_domain")
    p.add_argument("--config", dest="config", default=None, help="path to config.yaml")
    return p.parse_args()

async def _check_all(cfg):
    names: List[str] = storage.list_domains()
    async with Dispatcher(cfg) as d:
        for name in names:
            results = await d.run_for(name)
            for r in results:
                storage.save_history(name, r.check, r.status, r.message, r.metrics)
            print(name, "->", ", ".join(f"{r.check}:{r.status}" for r in results))

async def _check_one(cfg, name: str):
    async with Dispatcher(cfg) as d:
        results = await d.run_for(name)
        for r in results:
            storage.save_history(name, r.check, r.status, r.message, r.metrics)
        print(name, "->", ", ".join(f"{r.check}:{r.status}" for r in results))

def main() -> None:
    ns = _parse_args()
    cfg = load_config(ns.config)
    storage.init_db()

    if ns.mode == "bot":
        run_bot(cfg)                      # <-- синхронный запуск
    elif ns.mode == "check_all":
        asyncio.run(_check_all(cfg))
    else:
        if not ns.name:
            raise SystemExit("usage: python -m sitewatcher.main check_domain <name>")
        asyncio.run(_check_one(cfg, ns.name))

if __name__ == "__main__":
    main()
