# sitewatcher/dispatcher.py
from __future__ import annotations

import asyncio
import json
from typing import Dict, Iterable, List, Optional, Sequence
import httpx

from .config import AppConfig, ResolvedSettings, resolve_settings
from .checks.base import CheckOutcome, Status
from .checks.http_basic import HttpBasicCheck
from .checks.tls_cert import TlsCertCheck
from .checks.keywords import KeywordsCheck
from .checks.ping import PingCheck
from .checks.ports import PortsCheck
from .checks.whois_info import WhoisInfoCheck
from .checks.ip_blacklist import IpBlacklistCheck
from .checks.ip_change import IpChangeCheck
from . import storage

# RKN-плагин на SQLite-индексе
try:
    from .checks.rkn_block_sqlite import RknBlockCheck  # рекомендованный
except Exception:  # pragma: no cover
    # на случай, если файл ещё не добавлен — не валим импортом
    RknBlockCheck = None  # type: ignore


class Dispatcher:
    """
    Оркестратор проверок:
      - держит общий httpx.AsyncClient (HTTP/2 при наличии h2, иначе HTTP/1.1);
      - ограничивает параллелизм семафором;
      - собирает активные проверки по домену и запускает их конкурентно.
    """

    def __init__(self, cfg: AppConfig, max_concurrency: int = 10) -> None:
        self.cfg = cfg
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "Dispatcher":
        # Пытаемся HTTP/2, иначе мягко откатываемся на HTTP/1.1
        try:
            self._client = httpx.AsyncClient(http2=True)
        except Exception:
            self._client = httpx.AsyncClient(http2=False)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # ----------------- публичные методы -----------------

    async def run_for(
        self,
        domain: str,
        only_checks: Optional[Iterable[str]] = None,
        use_cache: bool = False,
    ) -> List[CheckOutcome]:
        """
        Выполнить проверки для домена.
        - only_checks: если задан список имён чеков, запускаем только их
        - use_cache: если True, для чеков с cache_ttl_minutes>0 попробуем вернуть свежий результат из history
        """
        settings = self._resolve(domain)
        checks = self._build_checks(settings)

        if only_checks:
            allowed = set(map(str, only_checks))
            checks = [c for c in checks if getattr(c, "name", "") in allowed]

        def _ttl_minutes(check_name: str) -> int:
            # cfg.schedules.<check>.cache_ttl_minutes (если такого блока нет — считаем 0)
            sc = getattr(self.cfg.schedules, check_name, None)
            try:
                return int(getattr(sc, "cache_ttl_minutes", 0) or 0) if sc is not None else 0
            except Exception:
                return 0

        results: List[CheckOutcome] = []
        for chk in checks:
            name = getattr(chk, "name", "")

            if use_cache:
                ttl = _ttl_minutes(name)
                if ttl > 0:
                    row = storage.last_history_for_check(domain, name)
                    if row:
                        mins = storage.minutes_since_last(domain, name)
                        if mins is not None and mins <= ttl:
                            try:
                                metrics = json.loads(row["metrics_json"] or "{}")
                            except Exception:
                                metrics = {}
                            results.append(
                                CheckOutcome(
                                    check=name,
                                    status=row["status"],
                                    message=f'{row["message"]} [cached {mins}m]',
                                    metrics=metrics,
                                )
                            )
                            continue  # не запускаем сетевой чек

            # живой запуск чека
            try:
                res = await chk.run()
            except Exception as e:
                res = CheckOutcome(name, Status.UNKNOWN, f"error: {e.__class__.__name__}", {})
            results.append(res)

        return results

    async def run_many(self, domains: Sequence[str]) -> Dict[str, List[CheckOutcome]]:
        """
        Удобный помощник для запуска по нескольким доменам.
        Возвращает словарь {domain: [CheckOutcome, ...]}.
        """
        assert self._client is not None, "Use 'async with Dispatcher(cfg) as d:'"

        async def _run(name: str) -> tuple[str, List[CheckOutcome]]:
            return name, await self.run_for(name)

        pairs = await asyncio.gather(*(_run(d) for d in domains))
        return {name: outcomes for name, outcomes in pairs}

    # ----------------- внутреннее -----------------

    def _resolve(self, domain: str) -> ResolvedSettings:
        """Оборачиваем resolve_settings(..) в метод класса."""
        return resolve_settings(self.cfg, domain)

    def _build_checks(self, settings: ResolvedSettings) -> List:
        """
        Собирает список инстансов проверок по включённым флажкам.
        """
        assert self._client is not None

        out: List = []

        if getattr(settings.checks, "http_basic", False):
            out.append(
                HttpBasicCheck(
                    settings.name,
                    client=self._client,
                    timeout_s=settings.http_timeout_s,
                    latency_warn_ms=settings.latency_warn_ms,
                    latency_crit_ms=settings.latency_crit_ms,
                    proxy=settings.proxy,
                )
            )

        if getattr(settings.checks, "tls_cert", False):
            out.append(TlsCertCheck(settings.name, warn_days=settings.tls_warn_days))

        if getattr(settings.checks, "keywords", False):
            out.append(
                KeywordsCheck(
                    settings.name,
                    client=self._client,
                    timeout_s=settings.http_timeout_s,
                    keywords=settings.keywords,
                )
            )

        if getattr(settings.checks, "ping", False):
            out.append(PingCheck(settings.name))

        if getattr(settings.checks, "rkn_block", False) and RknBlockCheck is not None:
            out.append(
                RknBlockCheck(
                    settings.name,
                    client=self._client,
                    rkn_cfg=self.cfg.rkn,
                )
            )

        if getattr(settings.checks, "ports", False):
            # список целей: доменные override или глобальные
            targets = getattr(settings, "ports", None) or self.cfg.ports.targets
            out.append(
                PortsCheck(
                    settings.name,
                    targets=targets if targets else self.cfg.ports.targets,
                    defaults=self.cfg.ports,
                )
            )

        if getattr(settings.checks, "whois", False):
            out.append(
                WhoisInfoCheck(
                    settings.name,
                    client=self._client,
                    cfg=self.cfg.whois,
                )
            )

        if getattr(settings.checks, "ip_blacklist", False):
            out.append(
                IpBlacklistCheck(
                    settings.name,
                    zones=self.cfg.ipbl.zones,
                    dns_servers=self.cfg.ipbl.dns_servers,
                    timeout_s=self.cfg.ipbl.timeout_s,
                    concurrency=self.cfg.ipbl.concurrency,
                    check_ipv6=self.cfg.ipbl.check_ipv6,
                )
            )

        if getattr(settings.checks, "ip_change", False):
            out.append(IpChangeCheck(settings.name, cfg=self.cfg.ipchange))

        return out

    @staticmethod
    def _normalize_results(results: Iterable[object]) -> List[CheckOutcome]:
        """
        Преобразует результаты asyncio.gather с return_exceptions=True
        в единый список CheckOutcome, аккуратно оборачивая исключения.
        """
        out: List[CheckOutcome] = []
        for r in results:
            if isinstance(r, Exception):
                out.append(
                    CheckOutcome(
                        check="internal",
                        status=Status.CRIT,
                        message=f"{r.__class__.__name__}: {r}",
                        metrics={},
                    )
                )
            else:
                out.append(r)  # type: ignore[arg-type]
        return out
